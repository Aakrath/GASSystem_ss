// Copyright SS Mechanics

#pragma once

#include "CoreMinimal.h"

#define  CUSTOM_DEPTH_RED 250

