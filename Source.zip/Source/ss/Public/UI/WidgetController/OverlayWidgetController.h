// Copyright SS Mechanics

#pragma once

#include "CoreMinimal.h"
#include "UI/WidgetController/ssWidgetController.h"
#include "OverlayWidgetController.generated.h"

/**
 * 
 */
UCLASS()
class SS_API UOverlayWidgetController : public UssWidgetController
{
	GENERATED_BODY()
	
};
