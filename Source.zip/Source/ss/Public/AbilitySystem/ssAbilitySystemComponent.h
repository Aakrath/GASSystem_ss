// Copyright SS Mechanics

#pragma once

#include "CoreMinimal.h"
#include "AbilitySystemComponent.h"
#include "ssAbilitySystemComponent.generated.h"

/**
 * 
 */
UCLASS()
class SS_API UssAbilitySystemComponent : public UAbilitySystemComponent
{
	GENERATED_BODY()
	
};
