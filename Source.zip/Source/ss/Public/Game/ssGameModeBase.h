// Copyright SS Mechanics

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/GameModeBase.h"
#include "ssGameModeBase.generated.h"

/**
 * 
 */
UCLASS()
class SS_API AssGameModeBase : public AGameModeBase
{
	GENERATED_BODY()
	
};
